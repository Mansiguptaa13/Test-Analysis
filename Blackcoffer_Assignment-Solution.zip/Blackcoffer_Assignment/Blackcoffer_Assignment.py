#!/usr/bin/env python
# coding: utf-8

# ## Blackcoffer Assignment

# In[70]:


# Importing required libraries
import pandas as pd
from bs4 import BeautifulSoup
import requests
import os
import string
import nltk
from nltk.corpus import stopwords
import re
from nltk.tokenize import sent_tokenize, word_tokenize


# In[2]:


# To get the current working directory
os.getcwd()


# In[3]:


# Load the input data
input_data = pd.read_excel("Input.xlsx")


# In[6]:


# Accessing each article from the input excel file

for index, row in input_data.iterrows():
    url = row['URL']
    response = requests.get(url)   # It simplifies the process of sending HTTP requests and handling responses.
    soup = BeautifulSoup(response.content, 'html.parser') # Parsing HTML content to read

    # Extract article title and text
    # Used two different classes to resolve issue with some articles having images at the start of the article.
    title_element = soup.find('title')
    if soup.find('div', class_= 'td-post-content tagdiv-type'):
        
        text_element = soup.find('div', class_='td-post-content tagdiv-type')
    else:
        text_element = soup.find('div', class_='td_block_wrap tdb_single_content tdi_130 td-pb-border-top td_block_template_1 td-post-content tagdiv-type')


    # Check if the elements exist before accessing their text
    if title_element is not None:
        article_title = title_element.get_text()
    else:
        article_title = "Title not found"

    if text_element is not None:
        # Check if 'pre' tag exists before extracting. For removing the footer from the articles main content.
        pre_element = text_element.find('pre')
        if pre_element:
            unwanted = pre_element.extract()

            article_text = text_element.get_text()
        else:
            article_text = text_element.get_text()
        
        # Save the text to a file
    
        with open(f'{row["URL_ID"]}.txt', 'w', encoding='utf-8') as file:
            file.write(f'{article_title}\n\n{article_text}')
        
    else:
        article_text = "Text not found"
        print(row['URL_ID'])


# ## Text Analysis

# ## Code to create a combined stop word file
# 

# In[7]:


# Function to read stop words files from StopWords folder and combine them
def read_and_combine_stopwords(stopwords_folder):
    combined_stopwords = set()

    # Iterate through each file in the folder
    for filename in os.listdir(stopwords_folder):
        filepath = os.path.join(stopwords_folder, filename)

        # Read stop words from the each file and make a single file of stop words called combined_stopwords.
        with open(filepath, 'r') as file:
            stop_words = file.read().split()
            combined_stopwords.update(stop_words)

    return combined_stopwords

# Folder containing stop words files
stopwords_folder = 'StopWords'

# Combine stop words from multiple files
all_stopwords = read_and_combine_stopwords(stopwords_folder)

# Save the combined stop words to a new file
with open('combined_stopwords.txt', 'w') as file:
    file.write('\n'.join(all_stopwords))

print("Combined stop words saved to 'combined_stopwords.txt'")


# ## To create filtered files of positive and negative words 

# In[63]:


# Function to remove stop words from a positive and negative words file.
def remove_stopwords(input_file, stopwords_file, output_file):
    # Read the content of the input file
    with open(input_file, 'r') as file:
        content = file.read()

    # Read the stop words
    with open(stopwords_file, 'r') as stopword_file:
        stopwords = stopword_file.read().splitlines()

    # Remove stop words from the content
    filtered_content = ' '.join(word for word in content.split() if word.lower() not in stopwords)

    # Write the filtered content to the output file
    with open(output_file, 'w') as output_file:
        output_file.write(filtered_content)

# Saving the stopword free positive and negative words file.
remove_stopwords('positive_words.txt', 'combined_stopwords.txt', 'filtered_positive.txt')
remove_stopwords('negative_words.txt', 'combined_stopwords.txt', 'filtered_negative.txt')

print("Filtered file successfully created")


# ## 1(a,b,c) - Code to calculate the Positive, Negative and Polarity Score

# In[64]:


# Function to calculate positive and negative score

def calculate_score(file_path, word_file):
    
    # Tokenize the text
    words = file_path.split()

    # Calculate score
    score = sum(1 for word in word_file if word in words)

    return score

# Function to calculate polarity score

def calculate_polarity_score(positive_score, negative_score):
    denominator = (positive_score + negative_score) + 0.000001
    polarity_score = (positive_score - negative_score) / denominator
    return polarity_score

# Read positive and negative word lists from files
with open(positive_word_file, 'r', encoding='utf-8', errors = 'replace') as pfile:
    positive_words = pfile.read().lower().split()

with open(negative_word_file, 'r', encoding='utf-8', errors = 'replace') as nfile:
    negative_words = nfile.read().lower().split()

# Calculate positive and negative scores for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()
        
            positive_score = calculate_score(text, positive_words)
            negative_score = calculate_score(text, negative_words)
            polarity_score = calculate_polarity_score(positive_score, negative_score)

        #print(f'File: {filename}, Polarity Score: {polarity_score:.2f}', )


# ## 1(d) - Code for calculating Subjectivity Score

# In[65]:


# Function to calculate subjectivity score
def calculate_subjectivity_score(positive_score, negative_score, total_words):
    denominator = (total_words) + 0.000001
    subjectivity_score = (positive_score + negative_score) / denominator
    return subjectivity_score

# Calculate subjectivity score for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read().lower()

        # Remove stopwords
        stop_words = 'combined_stopwords.txt'
        words = [word for word in text.split() if word not in stop_words]

        total_words = len(words)

        positive_score = calculate_score(text, positive_words)
        negative_score = calculate_score(text, negative_words)
        subjectivity_score = calculate_subjectivity_score(positive_score, negative_score, total_words)

        #print(f'File: {filename}, Subjectivity Score: {subjectivity_score:.2f}')


# ## 2 - Code for Analysis of Readability

# ### Sentence Count

# In[67]:


# Function to count sentences in a text file
def count_sentences(file_path):
    
    # Tokenize the text into sentences
    sentences = sent_tokenize(file_path)

    # Count the number of sentences
    sentence_count = len(sentences)

    return sentence_count

# Count sentences for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()
            sentence_count = count_sentences(text) # calling the function to count the sentences in an article
            #print(f'File: {filename}, Sentence Count: {sentence_count}')


# ### Average Sentence Length 

# In[68]:


# Calculate average sentence length for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()
            
        # Calculate average sentence length
        sentence_count = count_sentences(text)
        words = [word for word in text.split() if word not in stop_words]
        total_words = len(words)

        if sentence_count > 0:
            average_sentence_length = total_words / sentence_count
            
            #print(f'File: {filename}, Average Sentence Length: {average_sentence_length:.2f} words')
       


# ### Percentage of Complex words 

# In[69]:


nltk.download('cmudict')

# Function to count sentences, words, and complex words in a text file
def count_complex_words(file_path, pronouncing_dict):
    
    # Tokenize the text into words
    words = word_tokenize(text)
    words_temp = [word for word in words if word not in stop_words]

    # Count the number of complex words
    complex_word_count = 0
    for word in words_temp:
        if word.isalpha() and len(pronouncing_dict.get(word, [])) > 2:
            complex_word_count += 1

    return complex_word_count

# Download the CMU Pronouncing Dictionary
pronouncing_dict = cmudict.dict()

# Calculate percentage of complex words for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()

        complex_word_count = count_complex_words(text, pronouncing_dict)
          
        words = [word for word in text.split() if word not in stop_words]
        total_words = len(words)

        # Calculate percentage of complex words
        if total_words > 0:
            percentage_complex_words = (complex_word_count / total_words) * 100
            #print(f'File: {filename}, Percentage of Complex Words: {percentage_complex_words:.2f}%')
       


# ### Fog Index

# In[71]:


# Calculate Fog Index for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()

    sentence_count = count_sentences(text)
    words = [word for word in text.split() if word not in stop_words]
    total_words = len(words)

    if sentence_count > 0:
        average_sentence_length = total_words / sentence_count

    complex_word_count = count_complex_words(text, pronouncing_dict)
          
    # Calculate percentage of complex words
    if total_words > 0:
        percentage_complex_words = (complex_word_count / total_words) * 100

    fog_index = 0.4 * (average_sentence_length + percentage_complex_words)
   # print(f'File: {filename}, Fog Index: {fog_index:.2f}')


# ## 3 - Average Number of Words Per Sentence

# In[21]:


# Function to calculate Average Number of Words Per Sentence for a text file
def calculate_avg_words_per_sentence(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().lower()

    # Tokenize the text into sentences
    sentences = sent_tokenize(text)

    # Count the number of sentences
    sentence_count = len(sentences)

    # Tokenize the text into words
    words = word_tokenize(text)

    # Count the number of words
    total_word_count = len(words)

    # Calculate Average Number of Words Per Sentence
    avg_words_per_sentence = total_word_count / sentence_count
    return avg_words_per_sentence

# Calculate Average Number of Words Per Sentence for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        avg_words_per_sentence = calculate_avg_words_per_sentence(file_path)
#         print(f'File: {filename}, Average Number of Words Per Sentence: {avg_words_per_sentence:.2f}')


# In[72]:


# Calculate average sentence length for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()
        # Calculate average sentence length
        sentence_count = count_sentences(text)
        words = [word for word in text.split() if word not in stop_words]
        total_words = len(words)

        if sentence_count > 0:
            average_sentence_length = total_words / sentence_count
            
        
            #print(f'File: {filename}, Average Number of Words Per Sentence: {average_sentence_length:.2f} words')
       


# ## 4 - Code for Complex words

# In[73]:


# Function to count syllables in a word using CMU Pronouncing Dictionary
def syllable_count(word, pronouncing_dict):
    return max([len(list(y for y in x if y[-1].isdigit())) for x in pronouncing_dict[word.lower()]]) if word.lower() in pronouncing_dict else 0

# Function to calculate complex word count for a text file
def calculate_complex_word_count(text, stop_words, pronouncing_dict):
    words = word_tokenize(text)
    complex_word_count = sum(1 for word in words if syllable_count(word, pronouncing_dict) > 2 and word.lower() not in stop_words)
    return complex_word_count

# Calculate complex word count for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)

    # Check if the file is a text file
    if file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8', errors = 'replace') as file:
            text = file.read().lower()
            
        complex_word_count = calculate_complex_word_count(text, stop_words, pronouncing_dict)

#         print(f'File: {filename}, Complex Word Count: {complex_word_count}')


# ## 5 - Code for Word Count

# In[74]:


# Function to count cleaned words in a text file
def count_cleaned_words(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().lower()

    # Remove stopwords
    stop_words = 'stopwords'
    words = [word for word in text.split() if word not in stop_words]

    # Remove punctuation
    words = [''.join(char for char in word if char not in string.punctuation) for word in words]

    # Remove empty strings
    words = [word for word in words if word]

    # Count the cleaned words
    cleaned_word_count = len(words)

    return cleaned_word_count

# Count cleaned words for each text file
total_cleaned_word_count = 0
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        cleaned_word_count = count_cleaned_words(file_path)
        #print(f'File: {filename}, Total Words: {cleaned_word_count})


# ## 6 - Code for Syllable Count Per Word

# In[75]:


# Funtion to count syllable per word
def count_syllables(word):
    vowels = "aeiouy"
    count = 0

    for char in word:
        char = char.lower()
        if char in vowels:
            count += 1

    # Handle special cases
    if word.endswith("es"):
        count -= 1
    elif word.endswith("ed"):
        count -= 1

    return count  

def calculate_syllable_count_per_word(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().lower()

    # Remove stopwords and punctuations
    stop_words = 'combined_stopwords.txt'
    words = [''.join(char for char in word if char.isalnum()) for word in text.split() if word.lower() not in stop_words]

    # Calculate syllable count per word for each word
    syllable_counts = [count_syllables(word) for word in words]
    
    average_syllable_count = sum(syllable_counts) / len(syllable_counts)

    return average_syllable_count

# Calculate syllable count per word for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)

    # Check if the file is a text file
    if file_path.endswith('.txt'):
        syllable_counts_per_word = calculate_syllable_count_per_word(file_path)

        # Calculate and print the average syllable count per word for the file
        #print(f'File: {filename}, Average Syllable Count Per Word: {syllable_counts_per_word:.2f}')


# ## 7 - Code for Personal Pronouns

# In[80]:


# Assumption - All the repeated pronouns are considered in the counting.

def calculate_personal_pronouns(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()

    # Use regex to find and count personal pronouns
    pronoun_pattern = re.compile(r'\b(?:i|we|my|ours|us|I|My|Ours|We|Us)\b')
    pronoun_matches = pronoun_pattern.findall(text)

    # Exclude instances where the 'US' is country name    
    pronoun_count = len(pronoun_matches)
    for match in pronoun_matches:
        if match == 'US':
            pronoun_count -= 1

    return pronoun_count

# Define the path to the folder containing your text files
folder_path = 'Extracted_Files'

# Initialize total pronoun count
total_pronoun_count = 0

# Calculate personal pronouns count for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)

    # Check if the file is a text file
    if file_path.endswith('.txt'):
        pronoun_count = calculate_personal_pronouns(file_path)
        #print(f'File: {filename}, Personal Pronouns Count: {pronoun_count}')


# ## 8 - Average Word Length

# In[78]:


# # Funtion to count average_word_length

def calculate_average_word_length(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().lower()

    # Tokenize the text into words
    words = text.split()

    # Remove punctuation from each word
    words = [''.join(char for char in word if char not in string.punctuation) for word in words]

    # Calculate the total number of characters and total number of words
    total_characters = sum(len(word) for word in words)
    total_words = len(words)

    # Calculate Average Word Length
    average_word_length = total_characters / total_words

    return average_word_length

# Initialize total average word length
total_average_word_length = 0

# Calculate average word length for each text file
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)

    # Check if the file is a text file
    if file_path.endswith('.txt'):
        avg_word_length = calculate_average_word_length(file_path)
        #print(f'File: {filename}, Average Word Length: {avg_word_length:.2f}')


# In[79]:


# Creating variable as required to create Output Data.
data = {
    'URL_ID': [],
    'URL': [],
    'Positive Score': [],
    'Negative Score': [],
    'Polarity Score': [],
    'Subjectivity Score': [],
    'Average Sentence Length': [],
    'Percentage of Complex Words': [],
    'Fog Index': [],
    'Average Number of Words Per Sentence': [],
    'Complex Word Count': [],
    'Word Count': [],
    'Syllable Count Per Word': [],
    'Personal Pronouns Count': [],
    'Average Word Length': []
}


# Populate data dictionary with values
for filename in os.listdir(folder_path):
    file_path = os.path.join(folder_path, filename)
    
    
    # Check if the file is a text file
    if file_path.endswith('.txt'):
        
        # Extract URL ID from the filename
        url_id = filename.split('.')[0] 
        
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read().lower()

        stop_words = 'combined_stopwords.txt'
        words = [word for word in text.split() if word not in stop_words]

        total_words = len(words)
        
        sentence_count = count_sentences(text)
        
        complex_word_count = count_complex_words(text, pronouncing_dict)


        positive_score = calculate_score(text, positive_words)
        negative_score = calculate_score(text, negative_words)
        polarity_score = calculate_polarity_score(positive_score, negative_score)
        subjectivity_score = calculate_subjectivity_score(positive_score, negative_score, total_words)
        average_sentence_length = total_words / sentence_count
        percentage_complex_words = (complex_word_count / total_words) * 100
        fog_index = 0.4 * (average_sentence_length + percentage_complex_words)
        avg_words_per_sentence = average_sentence_length
        complex_word_count = calculate_complex_word_count(text, stop_words, pronouncing_dict)
        cleaned_word_count = count_cleaned_words(file_path)
        syllable_counts_per_word = calculate_syllable_count_per_word(file_path)
        pronoun_count = calculate_personal_pronouns(file_path)
        avg_word_length = calculate_average_word_length(file_path)

      
        # Replace these placeholders with your actual calculated values
        data['URL_ID'].append(str(url_id))
        data['URL'].append(url)  
        data['Positive Score'].append(positive_score)
        data['Negative Score'].append(negative_score)
        data['Polarity Score'].append(polarity_score)
        data['Subjectivity Score'].append(subjectivity_score)
        data['Average Sentence Length'].append(average_sentence_length)
        data['Percentage of Complex Words'].append(percentage_complex_words)
        data['Fog Index'].append(fog_index)
        data['Average Number of Words Per Sentence'].append(avg_words_per_sentence)
        data['Complex Word Count'].append(complex_word_count)
        data['Word Count'].append(cleaned_word_count)
        data['Syllable Count Per Word'].append(syllable_counts_per_word)
        data['Personal Pronouns Count'].append(pronoun_count)
        data['Average Word Length'].append(avg_word_length)


# Create a DataFrame from the data
df = pd.DataFrame(data)


# Save the DataFrame to an Excel file
df.to_excel('Output_Data.xlsx', index=False)

#print("Output_Data successfully created.")


# In[ ]:





# In[ ]:





# In[ ]:




